import onnxruntime as ort
import numpy as np
import os
import cv2
from .preprocess_and_post_process import *



class BCTCTableDetector:
    
    def __init__(self, model_dir, score_threshold=0.25, nms_threshold=0.5):
        self.postprocess_params = {
            'name': 'PicoDetPostProcess',
            "layout_dict_path": "/workspace/hoangtv/BctcSolutionFlow/table_detection/layout_table_dict.txt",
            "score_threshold": score_threshold,
            "nms_threshold": nms_threshold,
        }
        self.post_process_ops = self.build_post_process()
        
        self.model_dir = model_dir 
        self.detection_model = self.create_onnx_model()
        
    
    def build_post_process(self):
        support_dict = ['PicoDetPostProcess']
        config = copy.deepcopy(self.postprocess_params)
        module_name = config.pop('name')
        if module_name == "None":
            return
        assert module_name in support_dict, Exception(
            'Post process only support {}'.format(support_dict))
        module_class = eval(module_name)(**config)
        return module_class
    
    
    def create_onnx_model(self):
        model_file_path = self.model_dir
        if not os.path.exists(model_file_path):
            raise ValueError("Not find model file path {}".format(
                model_file_path))
        sess = ort.InferenceSession(model_file_path)
        return sess
    
    
    def filter_last_results(self, result_dicts):
        if len(result_dicts) > 1:
            bboxes_list = []
            filtered_list = []
            bboxes_idx_to_delete = []

            for result_dict in result_dicts:
                bboxes_list.append(result_dict["bbox"])

            for i in range(len(bboxes_list)):
                for j in range(i+1, len(bboxes_list)):
                    area_i = area_of(np.array([bboxes_list[i][0], bboxes_list[i][1]]), 
                                             np.array([bboxes_list[i][2], bboxes_list[i][3]]))
                    area_j = area_of(np.array([bboxes_list[j][0], bboxes_list[j][1]]), 
                                             np.array([bboxes_list[j][2], bboxes_list[j][3]]))
                    io_ma = io_min_area(bboxes_list[i], bboxes_list[j], min(area_i, area_j))
                    
                    if io_ma > 0.5:
                        if area_i > area_j:
                            bboxes_idx_to_delete.append(j)
                        else:
                            bboxes_idx_to_delete.append(i)

            for idx in range(len(result_dicts)):
                if idx not in bboxes_idx_to_delete:
                    filtered_list.append(result_dicts[idx])

            return filtered_list
        else:
            return result_dicts

    
    def inference_on_image(self, og_image):
        if not isinstance(og_image, np.ndarray):
            raise ValueError("Only support np.ndarray")
        input_tensor = prepare_input(og_image)
        preds = self.detection_model.run(None, {"image": input_tensor})
        
        np_score_list, np_boxes_list = [], []
        
        num_outs = int(len(preds)/2)
        for out_idx in range(num_outs):
            np_score_list.append(preds[out_idx])
            np_boxes_list.append(preds[out_idx + num_outs])

        dict_preds = dict(boxes=np_score_list, boxes_num=np_boxes_list)
        post_preds = self.post_process_ops(og_image, input_tensor, dict_preds)
        return self.filter_last_results(post_preds)
    
    
    def draw_result(self, og_image):
        results = self.inference_on_image(og_image)
        for result in results:
            bbox = [int(i) for i in result["bbox"]]
            cv2.rectangle(og_image,(bbox[0],bbox[1]),(bbox[2], bbox[3]),(0,255,0),2)
        return og_image